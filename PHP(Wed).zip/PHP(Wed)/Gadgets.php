<!DOCKTYPE html>
<html>

<head> <title> Welcome </title> 

<link rel="stylesheet" href="Gadgets.css"/>

</head>

<body>
<div class="Start">

 

<p>One of the trusted online shop in Bangladesh</p>
<h4>Contact with us +880-1677777777</h4>

</div>


<div class="head">
<marquee><p> Welcome to our shop <p></marquee>
<a href="login.php" class="log"> Login </a>
<a href="Register.html" class="Regis"> Register </a>
</div>

<div class="nav">

<a href="Home.php" class="a"> Home </a>
<a href="MenClothing.php" class="a"> Men's Collection </a>
<a href="Women.php" class="a"> Women's Collection </a>
<a href="Watch.php" class="a"> Watch zone </a>
<a href="Gadgets.php" class="a"> Mobile Gadget </a>



</div>



<img src="Images/ga1.jpg" title="fasion" height="400" width="300" class="mn1">
<img src="Images/ga2.jpg" title="fasion" height="400" width="300" class="mn2">
<img src="Images/ga3.jpg" title="fasion" height="400" width="300" class="mn3">
<img src="Images/ga4.jpg" title="fasion" height="400" width="300" class="mn4">
<img src="Images/ga5.jpg" title="fasion" height="400" width="300" class="mn4">







<div class="footer">

<p><b>INFORMATION</b></p>
<a href="Beabout.php" class="ah">About us</a>


</div>

</body>

</html>