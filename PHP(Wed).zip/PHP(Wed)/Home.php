<?php session_start();
$_SESSION["email"]="";
$_SESSION["type"]="";
?>
<!DOCKTYPE html>
<html>

<head> <title> Welcome </title> 

<link rel="stylesheet" href="Home.css"/>

</head>

<body>
<div class="Start">



<p>One of the trusted online shop in Bangladesh</p>
<h4>Contact with us +880-1677777777</h4>

</div>


<div class="head">
<marquee><p> Welcome to our shop <p></marquee>
<a href="login.php" class="log"> Login </a>
<a href="Register.html" class="Regis"> Register </a>
</div>

<div class="nav">

<a href="Home.php" class="a"> Home </a>
<a href="MenClothing.php" class="a"> Men's Collection </a>
<a href="Women.php" class="a"> Women's Collection </a>
<a href="Watch.php" class="a"> Watch zone </a>
<a href="Gadgets.php" class="a"> Mobile Gadget </a>


</div>

<img src="clothes.jpg" title="fasion" height="400" width="1525" class="img">

<div class="footer">

<p><b>INFORMATION</b></p>
<a href="Beabout.php" class="ah">About us</a>


</div>

</body>

</html>