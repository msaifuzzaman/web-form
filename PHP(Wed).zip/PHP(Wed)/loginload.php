<?php 

	$ar=array();
	include("login.php");
	loadArray();
	
	



?>